from django.test import TestCase

# Create unit tests to check store app
class StoreTest(TestCase):
    def test_store_page(self):
        response = self.client.get("/store/")
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "store/store.html")
        self.assertContains(response, "Store")
        self.assertContains(response, "Products")
        self.assertContains(response, "Categories")
        self.assertContains(response, "Cart")
        self.assertContains(response, "Checkout")
        self.assertContains(response, "Login")
        self.assertContains(response, "Register")
        self.assertContains(response, "Logout")
        self.assertContains(response, "Search")
        self.assertContains(response, "Add to cart")
        self.assertContains(response, "Remove from cart")
        self.assertContains(response, "Update cart")
        self.assertContains(response, "Checkout")
        self.assertContains(response, "Order summary")
        self.assertContains(response, "Order details")

# Create unit tests to check category view 
class CategoryTest(TestCase):
    def test_category_page(self):
        response = self.client.get("/store/category/1/")
        self.assertEqual(response.status_code, 200)
        self.assertTemplateUsed(response, "store/category.html")
        self.assertContains(response, "Categories")
        self.assertContains(response, "Products")
        self.assertContains(response, "Category")
        self.assertContains(response, "Add to cart")
        self.assertContains(response, "Remove from cart")
        self.assertContains(response, "Update cart")
        self.assertContains(response, "Checkout")
        self.assertContains(response, "Order summary")
        self.assertContains(response, "Order details")

       