from django.shortcuts import render , redirect , HttpResponseRedirect
from django.contrib.auth.hashers import  check_password
from store.models.customer import Customer
from django.views import View
from datetime import datetime
#VERIFICATION EMAIL
from django.contrib.sites.shortcuts import get_current_site
from django.template.loader import render_to_string
from django.utils.http import urlsafe_base64_decode, urlsafe_base64_encode
from django.utils.encoding import force_bytes
from django.contrib.auth.tokens import default_token_generator
from django.core.mail import EmailMessage

class Login(View):
    return_url = None

    def get(self, request):
        Login.return_url = request.GET.get ('return_url')
        return render (request, 'login.html')

    def post(self, request):
        email = request.POST.get ('email')
        password = request.POST.get ('password')
        customer = Customer.get_customer_by_email (email)
        error_message = None
        if customer:
            flag = check_password (password, customer.password)
            if flag:
                request.session['customer'] = customer.id

                if Login.return_url:
                    return HttpResponseRedirect (Login.return_url)
                else:
                    Login.return_url = None
                    return redirect ('homepage')
            else:
                error_message = 'Invalid Username or password.'
        else:
            error_message = 'Invalid Username or password.'


        return render (request, 'login.html', {'error': error_message})


# Create logout method
def logout(request):
    request.session.clear()
    return redirect('login')

# write method for forgot password
def forgotPassword(request):
    if request.method == "POST":
        email = request.POST['email']
        try:
            user = Customer.objects.get(email__exact=email)
        except Customer.DoesNotExist:
            user = None
        
        if user:
            #FORGOT PASSWORD EMAIL CODE
            # current_site = get_current_site(request)
            # mail_subject = 'Please reset your password'
            # message = render_to_string('reset_password_email.html', {
            #     'user': user,
            #     'domain': current_site,
            #     'uid': urlsafe_base64_encode(force_bytes(user.pk)),
            #     'token': default_token_generator.make_token(user),
            # })
            # to_email = email
            # send_mail = EmailMessage(mail_subject, message, to=[to_email])
            # send_mail.send()
            # messages.success(request, 'Password reset email has been sent to your registered email address ' + email)
            return redirect('resetPassword')
        else:
            messages.error(request, 'Customer doesnot exist')
            return redirect('forgotPassword')

    return render(request, 'forgotPassword.html')

# write method for resetPassword
def resetPassword_validation (request, uidb64, token):
    try:
        uid = urlsafe_base64_decode(uidb64).decode()
        uid = int(uid)
        print(uid)
        user = Customer._default_manager.get(pk=uid)
    except (TypeError, ValueError, OverflowError, Customer.DoesNotExist):
        user = None
    
    if user and default_token_generator.check_token(user, token):
        request.session['uid'] = uid
        messages.success(request, 'Please reset your password!')
        return redirect('resetPassword')
    else:
        messages.error(request, 'The reset password link has been expired!')
        return redirect('forgotPassword')

# write method to reset password
def resetPassword(request):
    if request.method == "POST":
        password = request.POST['password']
        confirm_password = request.POST['confirm_password']

        if password == confirm_password:
            uid = request.session.get('uid')
            uid = int(uid)
            print(uid)
            print(uid, password, confirm_password, uidb64, token, uid, user, default_token_generator.check_token(user, token), default_token_generator.make_token(user), default_token_generator.make_token(user), default_token_generator.make_)
            user = Customer.objects.get(pk=uid)
            user.set_password(password)
            user.save()
            messages.success(request, 'Password has been reset successfully!')
            return redirect('login')
        else:
            messages.error(request, 'Password does not match')
            return redirect('resetPassword')
    return render(request, 'resetPassword.html')

