from django.shortcuts import render, redirect

from django.contrib.auth.hashers import check_password
from store.models.customer import Customer
from django.views import View

from store.models.product import Products
from store.models.orders import Order
from store.middlewares.auth import auth_middleware
from datetime import datetime
import random
import string

# create Checkout View
class CheckOut(View):
    def post(self, request):
        address = request.POST.get('address')
        print('adress:',address)
        request.session['address']= address 
        phone = request.POST.get('phone')
        customer = request.session.get('customer')
        cart = request.session.get('cart')
        print(cart)
        products = Products.get_products_by_id(list(cart.keys()))
        
        for product in products:
            print(cart.get(str(product.id)))
            order = Order(customer=Customer(id=customer),
                          product=product,
                          price=product.price,
                          address=address,
                          phone=phone,
                          quantity=cart.get(str(product.id)))
            order.save()
            # order.status = True
            # order.save()
            request.session['address']= order.address 
        # request.session['cart'] = {}
        
        # if 'cart' in request.session:
        #     del request.session['cart']
        return redirect('payment')

class MakePayment(View):
    def get(self,request):
        total = 0
        customer = request.session.get('customer')
        address = request.session.get('address')
        order=Order.objects.filter(customer=Customer(id=customer),status=False)
        for item in order:
            total += item.price
        customer_obj = Customer.objects.get(id=customer)
        full_name = customer_obj.get_full_name()
        tax = round(0.02 * total,2)
        grand_total = total + tax 
        context = {'order': order,'customer': customer_obj,'address':address,
        'tax':tax,'total':total ,'grand_total':grand_total,'full_name':full_name}
        print(customer,address,order)
        return render(request , 'payment.html',context)

class completeOrder(View):
    def post(self,request):
        total = 0
        order_no = 0
        customer = request.session.get('customer')
        address = request.session.get('address')
        customer_obj = Customer.objects.get(id=customer)
        order=Order.objects.filter(customer=Customer(id=customer),status=False)
        full_name = customer_obj.get_full_name()
        print(full_name)
        for item in order:
            total += item.price
            item.status= True
            item.save()
        
        if 'cart' in request.session:
            del request.session['cart']
        
        tax = round(0.02 * total,2)
        grand_total = total + tax 
        order_date = datetime.now().date()
        
        random_string = ''
        for i in range(3):
            random_string += random.choice(string.ascii_letters).upper()

        random_digits = ''
        for i in range(7):
            random_digits += str(random.randint(0,9))
        
        transaction_id = random_string + random_digits
        
        order_no = ''
        for i in range(7):
            order_no += str(random.randint(0,9))

        context = {'order': order,'address':address,
        'tax':tax,'total':total ,'customer':customer_obj,'grand_total':grand_total,
        'order_date':order_date,'transaction_id':transaction_id,
        'address':address,'order_no':order_no,'full_name':full_name}

        return render(request,'completeorder.html',context)

class paymentMethod(View):
    def post(self,request):
        return render(request,'paymentmethod.html')
